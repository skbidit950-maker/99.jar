package com.ninety.nine;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = NinetyNine.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
class ClientKeyRegistration {
    static final KeyMapping MENU = new KeyMapping(
        "key.ninety_nine.menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
        "key.categories.ninety_nine"
    );

    @SubscribeEvent
    static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(MENU);
    }
}

@Mod.EventBusSubscriber(modid = NinetyNine.MOD_ID, value = Dist.CLIENT)
public class ClientFeatures {
    private static boolean menuOpen = false;
    private static boolean coordsEnabled = true;
    private static boolean armorEnabled = true;
    private static boolean chunkBordersEnabled = false;

    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (ClientKeyRegistration.MENU.consumeClick()) {
            menuOpen = !menuOpen;
            mc.player.displayClientMessage(Component.literal("99 Client menu " + (menuOpen ? "opened" : "closed")), true);
        }
    }

    @SubscribeEvent
    public static void onHud(RenderGuiOverlayEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        GuiGraphics g = event.getGuiGraphics();
        int y = 8;

        if (coordsEnabled) {
            String coords = String.format("XYZ: %.1f / %.1f / %.1f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ());
            g.drawString(mc.font, coords, 8, y, 0xFFE7E7E7, true);
            y += 12;
        }

        if (armorEnabled) {
            String armor = "Armor: " + mc.player.getArmorValue() + "/20";
            g.drawString(mc.font, armor, 8, y, 0xFFFF7777, true);
            y += 12;
        }

        if (menuOpen) {
            int x = 8, top = y + 8, width = 190, height = 82;
            g.fill(x, top, x + width, top + height, 0xDD111111);
            g.fill(x, top, x + width, top + 2, 0xFFB51F2B);
            g.drawString(mc.font, "99 CLIENT  |  RIGHT SHIFT", x + 8, top + 8, 0xFFFFFFFF, true);
            g.drawString(mc.font, "[C] Coordinates: " + (coordsEnabled ? "ON" : "OFF"), x + 8, top + 25, 0xFFE7E7E7, true);
            g.drawString(mc.font, "[A] Armor HUD: " + (armorEnabled ? "ON" : "OFF"), x + 8, top + 39, 0xFFE7E7E7, true);
            g.drawString(mc.font, "[B] Chunk borders: " + (chunkBordersEnabled ? "ON" : "OFF"), x + 8, top + 53, 0xFFE7E7E7, true);
            g.drawString(mc.font, "Keys: C / A / B", x + 8, top + 67, 0xFFAAAAAA, true);
        }
    }

    @SubscribeEvent
    public static void onKey(InputEvent.Key event) {
        if (event.getAction() != GLFW.GLFW_PRESS) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        if (menuOpen) {
            switch (event.getKey()) {
                case GLFW.GLFW_KEY_C -> coordsEnabled = !coordsEnabled;
                case GLFW.GLFW_KEY_A -> armorEnabled = !armorEnabled;
                case GLFW.GLFW_KEY_B -> chunkBordersEnabled = !chunkBordersEnabled;
            }
        }
    }

    @SubscribeEvent
    public static void onWorldRender(RenderLevelStageEvent event) {
        // Chunk-border visualization is intentionally left to Minecraft's built-in debug renderer.
        // F3+G toggles vanilla chunk borders without inspecting hidden or unloaded chunk data.
    }
}
