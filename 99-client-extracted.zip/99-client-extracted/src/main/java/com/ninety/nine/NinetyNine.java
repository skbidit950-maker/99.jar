package com.ninety.nine;

import net.minecraftforge.fml.common.Mod;

@Mod(NinetyNine.MOD_ID)
public class NinetyNine {
    public static final String MOD_ID = "ninety_nine";

    public NinetyNine() {
        // Client features are registered by ClientFeatures on the Forge event bus.
    }
}
